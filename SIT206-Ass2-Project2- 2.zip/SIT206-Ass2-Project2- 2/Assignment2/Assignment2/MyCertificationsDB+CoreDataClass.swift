//  MyCertificationsDB+CoreDataClass.swift

// Import Required Modules
import Foundation
import CoreData

@objc(MyCertificationsDB)

// Create empty class which inherits from NSManagedObject
public class MyCertificationsDB: NSManagedObject {
}
